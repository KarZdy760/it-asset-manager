from flask import Blueprint, render_template, request, redirect
from . import db
from .models import Asset

bp = Blueprint("main", __name__)

@bp.route("/")
def index():
    assets = Asset.query.order_by(Asset.hostname).all()
    return render_template("index.html", assets=assets)

@bp.route("/add", methods=["GET","POST"])
def add():
    if request.method == "POST":
        asset = Asset(
            hostname=request.form["hostname"],
            asset_type=request.form["asset_type"],
            owner=request.form["owner"],
            status=request.form["status"]
        )
        db.session.add(asset)
        db.session.commit()
        return redirect("/")
    return render_template("add_asset.html")
