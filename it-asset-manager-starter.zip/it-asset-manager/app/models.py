from . import db

class Asset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hostname = db.Column(db.String(100), nullable=False)
    asset_type = db.Column(db.String(50), nullable=False)
    owner = db.Column(db.String(100))
    status = db.Column(db.String(30), default="Active")
